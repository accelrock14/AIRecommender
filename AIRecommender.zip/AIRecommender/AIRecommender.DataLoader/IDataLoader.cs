﻿namespace AIRecommender.DataLoader
{
    public interface IDataLoader
    {
        BookDetails Load();
    }
}
